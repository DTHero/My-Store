import firebase from "firebase";
import 'firebase/auth';

var config = {
    apiKey: "AIzaSyA1tPN0OmyIXVWw-MZAD5Ax-jMkGxI1UeA",
    authDomain: "demothesis-1537119221548.firebaseapp.com",
    databaseURL: "https://demothesis-1537119221548.firebaseio.com",
    projectId: "demothesis-1537119221548",
    storageBucket: "demothesis-1537119221548.appspot.com",
    messagingSenderId: "181489784106"
  };
  if (!firebase.apps.length) {
    firebase.initializeApp(config);
  } else
  console.log("firebase cannot connect!");
 
export default firebase;

export const database = firebase.database();

export const auth = firebase.auth();