import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import { database } from "./firebase";

class App extends Component {

  constructor(props){
    super(props);
    this.state={
      data: null
    };
  }

  componentDidMount(){
    database.ref("/").on('value', (snapshot) => {
      console.log("data change", snapshot.val());
      this.setState({
        data: snapshot.val()
      });
    });
  }

  onChange = (e) => {
    this.setState({
      datanew: e.target.value
    }); 
  }

  onSubmit = (e) => {
    e.preventDefault();
    database.ref()
            .child("amazing")
            .set(this.state.datanew);
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
          { JSON.stringify(this.state.data,null,2) }
        </p>
        <form onSubmit={this.onSubmit}>
          <input type="text" value={this.state.datanew} onChange={this.onChange}/>
          <input type="submit" value="Submit"/>
        </form>
      </div>
    );
  }
}

export default App;
