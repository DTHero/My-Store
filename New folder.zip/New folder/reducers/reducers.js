import {combineReducers} from 'redux';

import CheckLogin from './CheckLogin';
import Loading from './Loading';

export default combineReducers({
  payload:CheckLogin,
  isLoading:Loading,
});