import {combineReducers} from 'redux';

import CheckLogin from './CheckLogin';
import Loading from './Loading';
import PutEvent from './PutEvent';

export default combineReducers({
  payload:CheckLogin,
  isLoading:Loading,
  eventInfo:PutEvent,
});