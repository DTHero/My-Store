import {CREATE_NEW, UPDATE} from './types';

const initialState = {};

export default function (state = initialState, action) {

    var {payload} = action;

    switch(action.type){
        case CREATE_NEW:
        case UPDATE:
            console.log(payload);
            return payload;
        default: 
            return state;
    }
}