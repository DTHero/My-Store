import {CHECK_LOGIN} from './types';

export default function (state = {}, action) {

    var payload = {
        username:action.uname,
        password:action.pass,
        isLogin:false
    }

    if(payload.username === 'thiennguyen' 
                && payload.password === 'thien1234')
        payload.isLogin = true;
    else if(payload.username === 'thiennguyen' 
                && payload.password !== 'thien1234')
        payload = null;

    return payload;
}