import {CHECK_LOGIN, LOADING, NOT_LOADING, CREATE_NEW, UPDATE} from './types';

export const checkLogin = (username, password) => 
({type:CHECK_LOGIN, uname:username, pass:password});

export const loading = () => ({type:LOADING});
export const holding = () => ({type:NOT_LOADING});

export const createEvent = (payload) => ({type:CREATE_NEW, payload});
export const updateEvent = (payload) => ({type:UPDATE, payload});