import {CHECK_LOGIN, LOADING, NOT_LOADING} from './types';

export const checkLogin = (username, password) => 
({type:CHECK_LOGIN, uname:username, pass:password});

export const loading = () => ({type:LOADING});
export const holding = () => ({type:NOT_LOADING});