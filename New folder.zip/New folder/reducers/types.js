// For authencating login
export const CHECK_LOGIN = 'checkLogin';

// For handling loading
export const LOADING = 'loading';
export const NOT_LOADING = 'notLoading';

// For update event data
export const CREATE_NEW = 'createNew';
export const UPDATE = 'update';