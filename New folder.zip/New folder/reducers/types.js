export const CHECK_LOGIN = 'checkLogin';

export const LOADING = 'loading';
export const NOT_LOADING = 'notLoading';