import React, { Component } from 'react';

import Button from '@material-ui/core/Button';

import './Login.css';
import Login from './Signin';
import Register from './Register';

class Loginscreen extends Component {
  constructor(props){
    super(props);
    this.state={
      username:'',
      password:'',
      loginscreen:[],
      loginmessage:'',
      buttonLabel:'Register',
      isLogin:true
    }
  }

  componentWillMount(){
    var loginscreen=[];
    loginscreen.push(<Login parentContext={this} appContext={this.props.parentContext}/>);
    var loginmessage = "Not registered yet, Register Now";
    this.setState({
                  loginscreen:loginscreen,
                  loginmessage:loginmessage
                    })
  }

  handleClick(event){
    var loginmessage;
    if(this.state.isLogin){
      var loginscreen=[];
      loginscreen.push(<Register parentContext={this}/>);
      loginmessage = "Already registered. Go to Login";
      this.setState({
                     loginscreen:loginscreen,
                     loginmessage:loginmessage,
                     buttonLabel:"Login",
                     isLogin:false
                   })
    }
    else{
      var loginscreen=[];
      loginscreen.push(<Login parentContext={this}/>);
      loginmessage = "Not Registered yet. Go to registration";
      this.setState({
                     loginscreen:loginscreen,
                     loginmessage:loginmessage,
                     buttonLabel:"Register",
                     isLogin:true
                   })
    }
  }

  render() {
    return (
      <main className="Login-layout">
            {this.state.loginscreen}
            <div className="Login-paper">
                {this.state.isLogin ?
                    <Button
                        className="Login-submit"
                        variant="outlined"
                        color="primary">
                        Forgot password?
                    </Button> : null
                }
                <Button className = "Login-submit"
                    label={this.state.buttonLabel}
                    color={this.state.isLogin ? "secondary" : "primary"}
                    variant={this.state.isLogin ? "outlined" : "contained"}
                    onClick={(event) => this.handleClick(event)}>
                        {this.state.loginmessage}
                </Button>
            </div>        
        </main>  
    );
  }
}

export default Loginscreen;