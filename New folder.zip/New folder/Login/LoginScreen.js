import React, { Component } from 'react';

import {connect} from 'react-redux';

import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import Paper from '@material-ui/core/Paper';

import * as actions from '../reducers/actions';
import './Login.css';
import Login from './Signin';
import Register from './Register';

function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

class Loginscreen extends Component {
  constructor(props){
    super(props);
    this.state={
      username:'',
      password:'',
      loginscreen:[],
      loginmessage:'',
      buttonLabel:'Register',
      isLogin:true
    }
  }

  componentWillMount(){
    var loginscreen=[];
    loginscreen.push(<Login parentContext={this} appContext={this.props.parentContext}/>);
    var loginmessage = "Not registered yet, Register Now";
    this.setState({
                  loginscreen:loginscreen,
                  loginmessage:loginmessage
                    })
  }

  handleClick(event){

    // this.props.loading();
    // sleep(1000);
      
    var loginmessage;
    if(this.state.isLogin){
      var loginscreen=[];
      loginscreen.push(<Register parentContext={this}/>);
      loginmessage = "Already registered. Go to Login";
      this.setState({
        loginscreen:loginscreen,
        loginmessage:loginmessage,
        buttonLabel:"Login",
        isLogin:false
      });
      // this.props.holding();
    }
    else{
      var loginscreen=[];
      loginscreen.push(<Login parentContext={this}/>);
      loginmessage = "Not Registered yet. Go to registration";
      this.setState({
                     loginscreen:loginscreen,
                     loginmessage:loginmessage,
                     buttonLabel:"Register",
                     isLogin:true
                   });
      // this.props.holding();
    }
  }

  render() {
    return (
      <main className="Login-layout">
        {
          this.props.isLoading ?
            <Paper className="Login-paper">
              <CircularProgress color='primary' thickness={7} />
            </Paper>
          :
          <div>
            {this.state.loginscreen}
            <div className="Login-paper">
                  {this.state.isLogin ?
                    <Button
                        className="Login-submit"
                        variant="outlined"
                        color="primary">
                        Forgot password?
                    </Button> : null
                  }
                <Button className = "Login-submit"
                    label={this.state.buttonLabel}
                    color={this.state.isLogin ? "secondary" : "primary"}
                    variant={this.state.isLogin ? "outlined" : "contained"}
                    onClick={(event) => this.handleClick(event)}>
                        {this.state.loginmessage}
                </Button>                
            </div>
          </div>
        }       
        </main>  
    );
  }
}

const mapStateToProps = state => ({
  isLoading: state.isLoading
});

export default connect(mapStateToProps, actions)(Loginscreen);