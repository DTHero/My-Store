import React, {Component} from 'react';

import {connect} from 'react-redux';
import "./Login.css";

import Avatar from '@material-ui/core/Avatar';
import FormControl from '@material-ui/core/FormControl';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import LockIcon from '@material-ui/icons/LockOutlined';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';

import {Link, Redirect, withRouter } from 'react-router-dom';
import * as actions from '../reducers/actions';
import {auth} from '../firebase';

class Login extends  Component {

  constructor(props){
    super(props);
    this.state={
    username:'',
    password:''
    }
   }

   handleClick(event){
    this.props.loading();
    var self = this;
    var params={
    "username":this.state.username,
    "password":this.state.password
    }

    console.log(params);
    
    // this.props.checkLogin(this.state.username,this.state.password);

    auth.signInWithEmailAndPassword(params.username, params.password)
    .then(() => {
      // this.setState({ ...INITIAL_STATE });
      this.props.holding();
      this.props.history.push('/main');
    })
    .catch(error => {
      // this.setState(byPropKey('error', error));
      console.log("Authen Failed!")
    });

  event.preventDefault();

    // if(this.props.payload !== null){
    //     if(this.props.payload.isLogin){
    //   console.log("Login successfull");
    //   var uploadScreen=[];  
    //     this.props.history.push('/main')
    //     // self.props.appContext.setState({loginPage:[],uploadScreen:uploadScreen})
    //     }
    //     else{
    //       console.log("Username or password does not exist, please try again!");
    //       alert("Username or password does not exist, please try again!");
    //     }
    // }
    // else{
    //   console.log("Please fill all fields!");
    //   alert("Please fill all fields!");
    // }
  }
    
  render() {
    return (
        <main className="Login-layout">
          <Paper className="Login-paper">
            <Avatar className="Login-avatar">
              <LockIcon />
            </Avatar>
            <Typography component="h1" variant="h5">
              Sign in
            </Typography>
            <form className="Login-form">
              <FormControl margin="normal" required fullWidth>
                <InputLabel htmlFor="username">Username</InputLabel>
                <Input 
                  defaultValue=''
                  id="username" 
                  name="username" 
                  autoComplete="username" 
                  autoFocus 
                  onChange = {(event) => this.setState({username:event.target.value})}/>
              </FormControl>
              <FormControl margin="normal" required fullWidth>
                <InputLabel htmlFor="password">Password</InputLabel>
                <Input
                  defaultValue=''
                  name="password"
                  type="password"
                  id="password"
                  autoComplete="current-password"
                  onChange = {(event) => this.setState({password:event.target.value})}
                />
              </FormControl>
              <FormControlLabel
                control={<Checkbox value="remember" color="primary" />}
                label="Remember me"
              />
              <p/>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                className="Login-submit"
                onClick={(event) => this.handleClick(event)}
              >
                Sign in
              </Button>
            </form>
          </Paper>
        </main>
  );
  }
}

const mapStateToProps = state => ({
  payload: state.payload,
  isLoading: state.isLoading
});

export default connect(mapStateToProps, actions)(withRouter(Login));