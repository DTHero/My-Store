import React, { Component } from 'react';

import AppBar from '@material-ui/core/AppBar';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';

import './Login.css';

class Register extends Component {
  constructor(props){
    super(props);
    this.state={
      first_name:'',
      last_name:'',
      email:'',
      password:''
    }
  }
  render() {
    return (
    <main className="Login-layout">
    <Paper className="Login-paper">
            <Typography component="h1" variant="h5">
              Register
            </Typography>
           <form className="Login-form">
           <FormControl margin="normal" fullWidth>
                <InputLabel htmlFor="first-name">Enter your first name</InputLabel>
                <Input 
                  id="first-name" 
                  name="first-name" 
                  autoFocus 
                  onChange = {(event,newValue) => this.setState({username:newValue})}/>
            </FormControl>
            <FormControl margin="normal" fullWidth>
                <InputLabel htmlFor="last-name">Enter your last name</InputLabel>
                <Input 
                  id="last-name" 
                  name="last-name" 
                  autoFocus 
                  onChange = {(event,newValue) => this.setState({username:newValue})}/>
            </FormControl>
            <FormControl margin="normal" required fullWidth>
                <InputLabel htmlFor="email">Enter your email</InputLabel>
                <Input 
                  id="email" 
                  name="email" 
                  autoComplete="email" 
                  autoFocus 
                  onChange = {(event,newValue) => this.setState({username:newValue})}/>
            </FormControl>
            <FormControl margin="normal" required fullWidth>
            <InputLabel htmlFor="password">Password</InputLabel>
                <Input
                  name="password"
                  type="password"
                  id="password"
                  autoComplete="current-password"
                  onChange = {(event,newValue) => this.setState({password:newValue})}
                />
            </FormControl>
            <FormControl margin="normal" required fullWidth>
                <InputLabel htmlFor="password">Re-enter password</InputLabel>
                <Input
                  name="re-password"
                  type="re-password"
                  id="re-password"
                  autoComplete="current-password"
                  onChange = {(event,newValue) => this.setState({password:newValue})}
                />
            </FormControl>
            <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                className="Login-submit"
                onClick={(event) => this.handleClick(event)}
              >
                Submit
              </Button>
              </form>
         </Paper>
         </main>
    );
  }
}

export default Register;