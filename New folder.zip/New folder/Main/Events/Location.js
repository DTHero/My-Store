import React, {Component} from 'react';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import GoogleMapReact from 'google-map-react';

const AnyReactComponent = ({ text }) => <div>{text}</div>;

class Location extends Component {

  render(){
  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Select location that event happens
      </Typography>
      <div style={{ height: '35vh', width: '100%' }}>
        <GoogleMapReact
          bootstrapURLKeys={{ key: 'AIzaSyA1tPN0OmyIXVWw-MZAD5Ax-jMkGxI1UeA' }}
          defaultZoom={12}
          defaultCenter={{lat:10.826567, lng:106.716425}}
        >
          <AnyReactComponent
            lat={10.83}
            lng={106.715}
            text={'Kreyser Avrora'}
          />
        </GoogleMapReact>
      </div>
      <Grid container spacing={16}>
          <TextField
              fullWidth
              disabled
              id="filled-disabled"
              defaultValue="Location view here"
              margin="normal"
              variant="filled"
          />
      </Grid>
    </React.Fragment>
  );
  }
}

export default Location;
