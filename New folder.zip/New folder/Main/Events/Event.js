import React, {Component} from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';

import {connect} from 'react-redux';
import * as actions from '../../reducers/actions';
import {database} from '../../firebase';

import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from '@material-ui/core/IconButton';
import Tooltip from '@material-ui/core/Tooltip';
import DeleteIcon from '@material-ui/icons/Delete';
import SaveIcon from '@material-ui/icons/Save';
import { lighten } from '@material-ui/core/styles/colorManipulator';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import CircularProgress from '@material-ui/core/CircularProgress';

function desc(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function stableSort(array, cmp) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = cmp(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map(el => el[0]);
}

function getSorting(order, orderBy) {
  return order === 'desc' ? (a, b) => desc(a, b, orderBy) : (a, b) => -desc(a, b, orderBy);
}

const rows = [
  { id: 'title', numeric: false, disablePadding: true, label: 'Title' },
  { id: 'start', numeric: true, disablePadding: false, label: 'Start date' },
  { id: 'end', numeric: true, disablePadding: false, label: 'End date' },
  { id: 'status', numeric: false, disablePadding: true, label: 'Status' },
  { id: 'note', numeric: false, disablePadding: true, label: 'Note' },
];

class CustomTable extends Component {
  createSortHandler = property => event => {
    this.props.onRequestSort(event, property);
  };

  render() {
    const { onSelectAllClick, order, orderBy, numSelected, rowCount } = this.props;
    
    const CustomCell = withStyles(theme => ({
      head: {
        backgroundColor: '#009688',
        color: '#ffc400',
        fontSize: 16,
      },
    }))(TableCell);

    return (
      <TableHead>
        <TableRow>
          <CustomCell padding="checkbox">
            <Checkbox
              indeterminate={numSelected > 0 && numSelected < rowCount}
              checked={numSelected === rowCount}
              onChange={onSelectAllClick}
            />
          </CustomCell>
          {rows.map(row => {
            return (
              <CustomCell
                key={row.id}
                numeric={row.numeric}
                padding={row.disablePadding ? 'none' : 'default'}
                sortDirection={orderBy === row.id ? order : false}
              >
                <Tooltip
                  title="Sort"
                  placement={row.numeric ? 'bottom-end' : 'bottom-start'}
                  enterDelay={300}
                >
                  <TableSortLabel
                    active={orderBy === row.id}
                    direction={order}
                    onClick={this.createSortHandler(row.id)}
                  >
                    {row.label}
                  </TableSortLabel>
                </Tooltip>
              </CustomCell>
            );
          }, this)}
        </TableRow>
      </TableHead>
    );
  }
}

CustomTable.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.string.isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

const toolbarStyles = theme => ({
  root: {
    paddingRight: theme.spacing.unit,
  },
  highlight:
    theme.palette.type === 'light'
      ? {
          color: theme.palette.secondary.main,
          backgroundColor: lighten(theme.palette.secondary.light, 0.85),
        }
      : {
          color: theme.palette.text.primary,
          backgroundColor: theme.palette.secondary.dark,
        },
  spacer: {
    flex: '1 1 100%',
  },
  actions: {
    color: theme.palette.text.secondary,
  },
  title: {
    flex: '0 0 auto',
  },
});

let EnhancedTableToolbar = props => {
  const { selected, classes, onDeleteClick, onSaveClick } = props;

  return (
    <Toolbar
      className={classNames(classes.root, {
        [classes.highlight]: selected.length > 0,
      })}
    >
      <div className={classes.title}>
        {selected.length > 0 ? (
          <Typography color="inherit" variant="subtitle1">
            {selected.length} selected
          </Typography>
        ) : (
          <Typography variant="h6" id="tableTitle">
            Current Events
          </Typography>
        )}
      </div>
      <div className={classes.spacer} />
      <div className={classes.actions}>
        {selected.length > 0 ? (
          <Tooltip title="Delete">
            <IconButton aria-label="Delete"
            onClick={onDeleteClick} >
              <DeleteIcon />
            </IconButton>
          </Tooltip>
        ) : (
          <Tooltip title="Save changes">
            <IconButton aria-label="Save"
            onClick={onSaveClick} >
              <SaveIcon />
            </IconButton>
          </Tooltip>
        )}
      </div>
    </Toolbar>
  );
};

EnhancedTableToolbar.propTypes = {
  classes: PropTypes.object.isRequired,
  selected: PropTypes.array.isRequired,
  onDeleteClick: PropTypes.func,
  onSaveClick: PropTypes.func,
};

EnhancedTableToolbar = withStyles(toolbarStyles)(EnhancedTableToolbar);

const styles = theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
  },
  table: {
    minWidth: 1020,
  },
  tableWrapper: {
    overflowX: 'auto',
  },
});

class EnhancedTable extends React.Component {
  state = {
    order: 'asc',
    orderBy:'',
    removedKeys:[],
    selected: [],
    data: [],
    page: 0,
    rowsPerPage: 5,
  };

  componentDidMount(){
    this.props.loading();
    this.getData();
    
  }

  getData = () =>{
    // Get data from firebase
    database.ref("/Events").once('value').then(snapshot => {
    let newState = [];
    snapshot.forEach(child => {
      let key = child.key;
      let item = child.val();
      newState.push({
        id: key,
        title: item.title,
        start: item.start,
        end: item.end,
        status: item.status,
        kind:item.kind,
        location:item.location,
        description:item.description,
      });
    })
    this.setState({ data: [...newState] })
    console.log(newState)
    this.props.holding();
  })

  } 

  handleRequestSort = (event, property) => {
    const orderBy = property;
    let order = 'desc';

    if (this.state.orderBy === property && this.state.order === 'desc') {
      order = 'asc';
    }

    this.setState({ order, orderBy });
  };

  handleSelectAllClick = event => {
    if (event.target.checked) {
      this.setState(state => ({ selected: state.data.map(n => n.id) }));
      return;
    }
    this.setState({ selected: [] });
  };

  handleClick = (event, id) => {
    const { selected } = this.state;
    const selectedIndex = selected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      );
    }

    this.setState({ selected: newSelected });
    console.log(newSelected);
  };
 
  handleChangePage = (event, page) => {
    this.setState({ page });
  };

  handleChangeRowsPerPage = event => {
    this.setState({ rowsPerPage: event.target.value });
  };

  handleChangeSelect = (id) => event => {
    var currData = [...this.state.data];

    currData.map((value, index) => {
      if(value.id===id){
        value.status = event.target.value;
      }
    })

    this.setState({
      data: currData,
    });

    console.log(this.state.data)
  };

  handleDeleteRow = () => {
    
    

    var newData = [...this.state.data];
    var removedKeys = [...this.state.selected]

    this.state.selected.map((value, index) => {
      var index = this.getIndex(value, newData, 'id');
      newData.splice(index,1);
    });

    this.setState({
      data: newData,
      selected:[]});

    console.log(newData);

    removedKeys.forEach(key => {
      database.ref(`/Events/${key}`).remove();
    })
    

  }

  updateEvents = () => {
    var updateData = [...this.state.data]
    

    this.props.updateEvent(this.state.data);
    console.log(this.props.eventInfo)
    updateData.forEach(event => {

      database.ref(`/Events/${event.id}`).update({
        status: event.status,
      });
    })
  }

  getIndex = (value, arr, prop) => {
    for(var i = 0; i < arr.length; i++) {
        if(arr[i][prop] === value) {
            return i;
        }
    }
    return -1;
  }

  isSelected = id => this.state.selected.indexOf(id) !== -1;

  render() {
    const { classes } = this.props;
    const { data, order, orderBy, selected, rowsPerPage, page } = this.state;
    const emptyRows = rowsPerPage - Math.min(rowsPerPage, data.length - page * rowsPerPage);

    return (
      <Paper className={classes.root}>
        <EnhancedTableToolbar 
          selected={selected}
          onSaveClick={this.updateEvents}
          onDeleteClick = {this.handleDeleteRow}
           />
        <div className={classes.tableWrapper}>
          {
          this.props.isLoading ?
              <Paper className="Login-paper">
                <CircularProgress color='primary' thickness={7} />
              </Paper>
            :
            <Table className={classes.table} aria-labelledby="tableTitle">
              <CustomTable
                numSelected={selected.length}
                order={order}
                orderBy={orderBy}
                onSelectAllClick={this.handleSelectAllClick}
                onRequestSort={this.handleRequestSort}
                rowCount={data.length}
              />
              <TableBody>
                {stableSort(data, getSorting(order, orderBy))
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map(n => {
                    const isSelected = this.isSelected(n.id);
                    return (
                      <TableRow
                        hover
                        role="checkbox"
                        aria-checked={isSelected}
                        tabIndex={-1}
                        key={n.id}
                        selected={isSelected}
                      >
                        <TableCell padding="checkbox">
                          <Checkbox 
                          checked={isSelected}
                          onClick={event => this.handleClick(event, n.id)} />
                        </TableCell>
                        <TableCell component="th" scope="row" padding="none">
                          {n.title}
                        </TableCell>
                        <TableCell numeric>{n.start}</TableCell>
                        <TableCell numeric>{n.end}</TableCell>
                        <TableCell component="th" scope="row" padding="none">
                          <Select
                                value={n.status}
                                onChange = {this.handleChangeSelect(n.id)}
                                name="status"
                                inputProps={{
                                id: 'status-required',
                                }}
                            >
                                <MenuItem value={'Approved'}>Approved</MenuItem>
                                <MenuItem value={'Pending'}>Pending</MenuItem>
                                <MenuItem value={'Rejected'}>Rejected</MenuItem>
                            </Select>
                        </TableCell>
                        <TableCell component="th" scope="row" padding="none">
                          0
                        </TableCell>
                      </TableRow>
                    );
                  })}
                {emptyRows > 0 && (
                  <TableRow style={{ height: 49 * emptyRows }}>
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
            </Table>
          }
        </div>
        <TablePagination
          component="div"
          count={data.length}
          rowsPerPage={rowsPerPage}
          page={page}
          backIconButtonProps={{
            'aria-label': 'Previous Page',
          }}
          nextIconButtonProps={{
            'aria-label': 'Next Page',
          }}
          onChangePage={this.handleChangePage}
          onChangeRowsPerPage={this.handleChangeRowsPerPage}
        />
      </Paper>
    );
  }
}

EnhancedTable.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapStateToProps = state => ({
  eventInfo: state.eventInfo,
  isLoading: state.isLoading
});

export default connect(mapStateToProps, actions)(withStyles(styles)(EnhancedTable));