import React from 'react';
import PropTypes from 'prop-types';

import {connect} from 'react-redux';
import * as actions from '../../reducers/actions';
import {auth} from '../../firebase';

import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';

const dataType = ['Title: ', 'Kind of sport: ', 'Start date: ', 'End date: ', 'Description: ', 'Location: '];

const styles = theme => ({
  listItem: {
    padding: `${theme.spacing.unit}px 0`,
  },
  total: {
    fontWeight: '700',
  },
  title: {
    marginTop: theme.spacing.unit * 2,
  },
});

class Review extends React.Component {
  
  render(){
    
    const {classes} = this.props;
    var payload = this.props.eventInfo;

      console.log(payload);
      return (
        <React.Fragment>
          <Typography variant="h6" gutterBottom>
            Summary
          </Typography>
          <List disablePadding>
            {Object.keys(payload).map((key, index)  => {
              
              const item = payload[key];
              const name = dataType[index];

              return(
                <ListItem className={classes.listItem} key={key}>
                  <Typography variant="body2">{name}</Typography>
                  <ListItemText primary={item} />
                </ListItem>)
            })}
          </List>
        </React.Fragment>
      );
  }
}

Review.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapStateToProps = state => ({
  eventInfo: state.eventInfo,
});

export default connect(mapStateToProps, actions)(withStyles(styles)(Review));