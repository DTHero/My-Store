import React from 'react';
import PropTypes from 'prop-types';

import {connect} from 'react-redux';
import * as actions from '../../reducers/actions';
import {database} from '../../firebase';

import withStyles from '@material-ui/core/styles/withStyles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Paper from '@material-ui/core/Paper';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import NewEvent from './NewEvent';
import Location from './Location';
import Review from './Review';

const styles = theme => ({
  appBar: {
    position: 'relative',
  },
  layout: {
    width: 'auto',
    marginLeft: theme.spacing.unit * 2,
    marginRight: theme.spacing.unit * 2,
    [theme.breakpoints.up(600 + theme.spacing.unit * 2 * 2)]: {
      width: 600,
      marginLeft: 'auto',
      marginRight: 'auto',
    },
  },
  paper: {
    marginTop: theme.spacing.unit * 3,
    marginBottom: theme.spacing.unit * 3,
    padding: theme.spacing.unit * 2,
    [theme.breakpoints.up(600 + theme.spacing.unit * 3 * 2)]: {
      marginTop: theme.spacing.unit * 6,
      marginBottom: theme.spacing.unit * 6,
      padding: theme.spacing.unit * 3,
    },
  },
  stepper: {
    padding: `${theme.spacing.unit * 3}px 0 ${theme.spacing.unit * 5}px`,
  },
  buttons: {
    display: 'flex',
    justifyContent: 'flex-end',
  },
  button: {
    marginTop: theme.spacing.unit * 3,
    marginLeft: theme.spacing.unit,
  },
});

const steps = ['Information', 'Location', 'Review'];

class Checkout extends React.Component {

  state = {
    activeStep: 0,
    key:'',
    title:'',
    kind: '',
    start:'',
    end:'',
    description:'',
    location:'',
  };

  getStepContent = (step) => {
    switch (step) {
      case 0:
        return <NewEvent onUpdate = {this.onUpdate}/>;
      case 1:
        return <Location />;
      case 2:
        return <Review />;
      default:
        throw new Error('Unknown step');
    }
  }

  handleNext = () => {
    
    var payload={
      title:this.state.title,
      kind:this.state.kind,
      start:this.state.start,
      end:this.state.end,
      description:this.state.description,
      location:this.state.location,
    }

    switch(this.state.activeStep){
      case 0:
      case 1:
        this.props.createEvent(payload);
        break;
      case 2:
        var newPostRef = database.ref().child("Events").push(this.props.eventInfo);
        this.setState({key: newPostRef.key});
        break;
      default:
        throw new Error('Unknown step');
    }

    this.setState(state => ({
      activeStep: state.activeStep + 1,
    }));

    // console.log(this.props.eventInfo);
  };

  handleBack = () => {
    this.setState(state => ({
      activeStep: state.activeStep - 1,
    }));
  };

  handleReset = () => {
    this.setState({
      activeStep: 0,
    });
  };

  onUpdate = (name, value) => {
    this.setState({
      [name]: value,
    });
  };

  render() {
    const { classes } = this.props;
    const { activeStep } = this.state;

    return (
      <React.Fragment>
        <CssBaseline />
        <main className={classes.layout}>
          <Paper className={classes.paper}>
            <Typography component="h1" variant="h4" align="center">
              New Event
            </Typography>
            <Stepper activeStep={activeStep} className={classes.stepper}>
              {steps.map(label => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
            <React.Fragment>
              {activeStep === steps.length ? (
                <React.Fragment>
                  <Typography variant="h5" gutterBottom>
                    Thank you for your submission.
                  </Typography>
                  <Typography variant="subtitle1">
                    Your submission data key is: {this.state.key}!
                  </Typography>
                  <Button
                      variant="contained"
                      color="primary"
                      onClick={this.handleReset}
                      className={classes.button}
                    >
                      OK
                    </Button>
                </React.Fragment>
              ) : (
                <React.Fragment>
                  {this.getStepContent(activeStep)}
                  <div className={classes.buttons}>
                    {activeStep !== 0 && (
                      <Button onClick={this.handleBack} className={classes.button}>
                        Back
                      </Button>
                    )}
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={this.handleNext}
                      className={classes.button}
                    >
                      {activeStep === steps.length - 1 ? 'Create Event' : 'Next'}
                    </Button>
                  </div>
                </React.Fragment>
              )}
            </React.Fragment>
          </Paper>
        </main>
      </React.Fragment>
    );
  }
}

Checkout.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mapStateToProps = state => ({
  eventInfo: state.eventInfo,
});

export default connect(mapStateToProps, actions)(withStyles(styles)(Checkout));