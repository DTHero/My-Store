import React, {Component} from 'react';
import ReactDOM from 'react-dom';

import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';

class NewEventForm extends Component {

    constructor(props){
        super(props);
        this.state = {
            title:'',
            kind: '',
            start:'',
            end:'',
            description:'',
    
            labelWidth: 0,
            multiline:'',
            imageURL:''
        };
    }
    
    
    // handleChange = event => {
    //     this.setState({ [event.target.name]: event.target.value });
    // };

    handleChange = name => event => {
        this.setState({
          [name]: event.target.value,
        });

        this.props.onUpdate(name,event.target.value);
      };

    render(){
        return (
            <React.Fragment>
            <Typography variant="h6" gutterBottom>
                Sport Information
            </Typography>
            <Grid container spacing={24}>
                <Grid item xs={12} sm = {8}>
                <TextField
                    required
                    id="title"
                    label="Title"
                    fullWidth
                    autoComplete="title"
                    value = {this.state.title}
                    onChange = {this.handleChange('title')}
                />
                </Grid>
                <Grid item xs={12} sm = {4}>
                    <FormControl required fullWidth >
                        <InputLabel htmlFor="kind-required">Kind of Sport</InputLabel>
                        <Select
                            value={this.state.kind}
                            onChange = {this.handleChange('kind')}
                            name="kind"
                            inputProps={{
                            id: 'kind-required',
                            }}
                        >
                            <MenuItem value="">
                            <em>Select a sport</em>
                            </MenuItem>
                            <MenuItem value={'Badminton'}>Badminton</MenuItem>
                            <MenuItem value={'Futsal'}>Futsal</MenuItem>
                            <MenuItem value={'Tennis'}>Tennis</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} sm ={6}>
                    <TextField
                        fullWidth
                        id="start-date"
                        label="From date"
                        type="date"
                        defaultValue="2018-01-01"
                        onChange = {this.handleChange('start')}
                        InputLabelProps={{
                        shrink: true,
                        }}
                    />
                </Grid>
                <Grid item xs={12} sm ={6}>
                    <TextField
                        fullWidth
                        id="end-date"
                        label="To date"
                        type="date"
                        defaultValue="2018-01-01"
                        onChange = {this.handleChange('end')}
                        InputLabelProps={{
                        shrink: true,
                        }}
                    />
                </Grid>
                <Grid item xs={12} sm ={9}>
                    <TextField
                        fullWidth
                        disabled
                        label="Image"
                        id="filled-disabled"
                        defaultValue={ this.state.imageURL === '' ? "Select your file path"
                                : this.state.imageURL}
                        margin="normal"
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} sm ={3}>
                    <input
                        accept="image/*"
                        id="contained-button-file"
                        multiple
                        type="file"
                        style={{visibility:'hidden'}}
                    />
                    <label htmlFor="contained-button-file">
                        <Button 
                            variant="contained" 
                            component="span"
                           >
                        Browse...
                        </Button>
                    </label>
                </Grid>
                <Grid item xs={12}>
                    <TextField
                        required
                        fullWidth
                        multiline
                        id="outlined-multiline-flexible"
                        label="Description"
                        rowsMax="5"
                        value={this.state.description}
                        onChange={this.handleChange('description')}
                        margin="normal"
                        helperText="Give some contents to describe the event"
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12}>
                <FormControlLabel
                    control={<Checkbox color="secondary" name="allowController" value="yes" />}
                    label="Allow people to enroll the event"
                />
                </Grid>
            </Grid>
            </React.Fragment>
        );
    }
}

export default NewEventForm;