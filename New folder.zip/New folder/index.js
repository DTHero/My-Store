import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import * as serviceWorker from './serviceWorker';
import { HashRouter, Route} from 'react-router-dom';

import LoginScreen from './Login/LoginScreen';
import MainScreen from './Main/MainPage';
import NewEvent from './Main/Events/NewEvent';


ReactDOM.render((
    <HashRouter> 
        <div>
            <Route path="/" component={MainScreen}/> 
            {/* <IndexRoute component={Pages}/> */}
        </div>
    </HashRouter>)
, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister(); 
