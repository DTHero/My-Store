package com.example.internntthien.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String USER_TO_MAIN="com.example.internntthien.loginapp.USER";
    public static final String PASSWORD_TO_MAIN="com.example.internntthien.loginapp.PASSWORD";

    private EditText un;
    private EditText pw;
    private Button bt;
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        connectView();

    }
    private void connectView() {
        tv = (TextView) findViewById(R.id.tv);
        un = (EditText) findViewById(R.id.un);
        pw = (EditText) findViewById(R.id.pw);
        bt = (Button) findViewById(R.id.bt);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doClickButton();
            }
        });
    }
    private void doClickButton() {
        String username = un.getText().toString().trim();
        String password = pw.getText().toString().trim();
        if ((username.equals("luonganhtuan")&&password.equals("luonganhtuan"))
                || (username.equals("nguyenthanhphuong")&&password.equals("nguyenthanhphuong"))
                || (username.equals("duongtrungvietanh")&&password.equals("duongtrungvietanh"))
                || (username.equals("nguyenthanhthien")&&password.equals("nguyenthanhthien"))) {
            loginSuccessful();
        } else {
            loginFail();
        }
    }
    public void loginSuccessful(){
        Intent intent = new Intent(this, Login.class);
        EditText uname=(EditText) findViewById(R.id.un);
        EditText pwd=(EditText) findViewById(R.id.pw);
        String username=uname.getText().toString().trim();
        String password=pwd.getText().toString().trim();
        intent.putExtra(USER_TO_MAIN,username);
        intent.putExtra(PASSWORD_TO_MAIN,password);
        startActivity(intent);
    }
    public void loginFail(){
        Toast toast=Toast.makeText(MainActivity.this, "Sorry, wrong username or password. Please try again",
                Toast.LENGTH_SHORT);
        toast.show();
    }
}
