package com.example.productsapp;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by intern.ntthien on 6/28/2017.
 */

public class ReadJson {
    // Đọc file company.json và chuyển thành đối tượng java.
    public static Products readProductsJSONFile(Context context) throws IOException,JSONException {

        // Đọc nội dung text của file company.json
        String jsonText = readText(context, R.raw.productjson);

        // Đối tượng JSONObject gốc mô tả toàn bộ tài liệu JSON.
        JSONObject jsonRoot = new JSONObject(jsonText);


        String id= jsonRoot.getString("id");
        String name = jsonRoot.getString("name");
        String min_price= jsonRoot.getString("min_price");
        String original_price= jsonRoot.getString("original_price");
        String value= jsonRoot.getString("value");

        Products product = new Products(id,name,min_price,original_price,value);
        product.setId(id);
        product.setName(name);
        product.setMin_rice(min_price);
        product.setOriginal_price(original_price);
        product.setValue(value);
        return product;
    }
    // Đọc nội dung text của một file nguồn.
    private static String readText(Context context, int resId) throws IOException {
        InputStream is = context.getResources().openRawResource(resId);
        BufferedReader br= new BufferedReader(new InputStreamReader(is));
        StringBuilder sb= new StringBuilder();
        String s= null;
        while((  s = br.readLine())!=null) {
            sb.append(s);
            sb.append("\n");
        }
        return sb.toString();
    }

}
