package com.example.productsapp;

import android.databinding.DataBindingUtil;
import android.databinding.ObservableField;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;

import com.example.productsapp.databinding.ActivityUserBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public ObservableField<String> tittle = new ObservableField<>();
    private ProductsAdapter productsAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityUserBinding binding = DataBindingUtil.setContentView(this
                , R.layout.activity_user);

        tittle.set("Products!");

        binding.setMain(this);
        setData();
        binding.productsView.setLayoutManager(new LinearLayoutManager(this));
        binding.productsView.setAdapter(productsAdapter);
    }
    public void setData() {
        List<Products> products = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            try {
                JSONObject jsonRoot = new JSONObject(ReadJson.readProductsJSONFile(this));
                JSONArray jsonArray = jsonRoot.getJSONArray("items");
                JSONObject items = jsonArray.getJSONObject(i);
                int id = items.getInt("id");
                String name = items.getString("name");

                JSONObject extension_attributes = items.getJSONObject("extension_attributes");
                int min_price = extension_attributes.getInt("min_price");
                int original_price = extension_attributes.getInt("original_price");

                JSONArray product_label = extension_attributes.getJSONArray("product_label");
                JSONObject getValue = product_label.getJSONObject(0);
                String value = getValue.getString("value");

                JSONArray custom_attributes = items.getJSONArray("custom_attributes");
                JSONObject getimgLink = custom_attributes.getJSONObject(1);
                String imgLink = getimgLink.getString("value");

                Products product = new Products();

                product.setId(i+1);
                product.setName(name);
                product.setMin_rice(min_price);
                product.setOriginal_price(original_price);
                if(!value.equals(""))
                product.setValue(value);
                else product.setValue("0%");
                product.setImgLink("https://api.lotte.vn/pub/media/catalog/product/"+imgLink);


                products.add(product);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        productsAdapter = new ProductsAdapter(products);
        }
    }
