package com.example.productsapp;

import android.databinding.DataBindingUtil;
import android.databinding.ObservableField;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;

import com.example.productsapp.databinding.ActivityUserBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public ObservableField<String> tittle = new ObservableField<>();
    private ProductsAdapter productsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityUserBinding binding = DataBindingUtil.setContentView(this
                , R.layout.activity_user);

        tittle.set("Products!");

        binding.setMain(this);
        setData();
        binding.productsview.setLayoutManager(new LinearLayoutManager(this));
        binding.productsview.setAdapter(productsAdapter);
    }
    public void setData(){
        try {
            // Đọc file: res/raw/company.json và trả về đối tượng Company.
            Products products = ReadJson.readProductsJSONFile(this);

            binding.setText(products.toString());
        } catch(Exception e)  {
            binding.setText(e.getMessage());
            e.printStackTrace();
        }
        List<Products> products = new ArrayList<>();
        for(int i=0;i<10;i++){
            try {
                // Đọc file: res/raw/company.json và trả về đối tượng Company.
                products = ReadJson.readProductsJSONFile(this);

                binding.setText(products.toString());
            } catch(Exception e)  {
                binding.setText(e.getMessage());
                e.printStackTrace();
            }
        }
        productsAdapter = new ProductsAdapter(products);
    }
}
