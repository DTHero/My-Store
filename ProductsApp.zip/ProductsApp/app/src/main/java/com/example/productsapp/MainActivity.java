package com.example.productsapp;

import android.databinding.DataBindingUtil;
import android.databinding.ObservableField;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.example.productsapp.databinding.ActivityUserBinding;

public class MainActivity extends AppCompatActivity {

    public ObservableField<String> tittle = new ObservableField<>();
    private ProductsAdapter productsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityUserBinding binding = DataBindingUtil.setContentView(this
                , R.layout.activity_user);
        tittle.set("Products!");
        binding.setMain(this);
        binding.productsview.setLayoutManager(new LinearLayoutManager(this));
        binding.productsview.setAdapter(productsAdapter);


    }
}
