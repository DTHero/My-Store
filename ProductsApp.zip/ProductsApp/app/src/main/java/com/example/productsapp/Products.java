package com.example.productsapp;

/**
 * Created by intern.ntthien on 6/27/2017.
 */

public class Products {
    private String id;
    private String name;
    private String min_price;
    private String original_price;
    private String value;

    public Products(String id, String name, String min_price
            , String original_price, String value) {
        this.id=id;
        this.name = name;
        this.min_price=min_price;
        this.original_price=original_price;
        this.value=value;
    }

    public String getId() { return this.id;}
    public String getName() { return this.name;}
    public String getMin_price(){ return this.min_price;}
    public String getOriginal_price(){ return this.original_price;}
    public String getValue(){ return this.value;}

    public void setId(String id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setMin_rice(String min_price) {
        this.min_price = min_price;
    }
    public void setOriginal_price(String original_price) {
        this.original_price = original_price;
    }
    public void setValue(String value) {
        this.value = value;
    }
}
