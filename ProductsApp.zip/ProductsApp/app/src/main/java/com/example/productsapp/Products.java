package com.example.productsapp;

/**
 * Created by intern.ntthien on 6/27/2017.
 */

public class Products {
    private int id;
    private String name;
    private long min_price;
    private long original_price;
    private String value;

    public Products(int id, String name, long min_price
            , long original_price, String value) {
        this.id=id;
        this.name = name;
        this.min_price=min_price;
        this.original_price=original_price;
        this.value=value;
    }

    public int getId() { return this.id;}
    public String getName() { return this.name;}
    public long getPrice(){ return this.min_price;}
    public long getOriginal_price(){ return this.original_price;}
    public String getValue(){ return this.value;}

    public void setId(int id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setMin_rice(long price) {
        this.min_price = price;
    }
    public void setOriginal_price(long original_price) {
        this.original_price = original_price;
    }
    public void setValue(String value) {
        this.value = value;
    }
}
