package com.example.productsapp;

import android.databinding.DataBindingUtil;
import android.databinding.ObservableField;
import android.graphics.Paint;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.productsapp.databinding.ItemProductsBinding;

import java.util.List;

/**
 * Created by intern.ntthien on 6/27/2017.
 */

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ViewHolder>{

    private List<Products> products;

    public ProductsAdapter(List<Products> products){
        this.products=products;
    }

    public ProductsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        ItemProductsBinding itemProductsBinding= DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),R.layout.item_products, parent, false);
        return new ViewHolder(itemProductsBinding);
    }   //Create new ViewHolder.

    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        holder.setBinding(products.get(position));
    }   //Binding data and view

    @Override
    public int getItemCount(){
        return products.size();
    } //Return the numbers of items

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ObservableField<String> id = new ObservableField<>();
        public ObservableField<String> name = new ObservableField<>();
        public ObservableField<String> min_price = new ObservableField<>();
        public ObservableField<String> original_price = new ObservableField<>();
        public ObservableField<String> value = new ObservableField<>();
        ImageView image;
//        TextView tv, tv2 ;
        private ItemProductsBinding itemProductsBinding;
        public ViewHolder(ItemProductsBinding itemView){
            super(itemView.getRoot());
            this.itemProductsBinding=itemView;
            image = itemView.image;
//            tv = itemView.originalPrice;
//            tv2 = itemView.vnd2;
        }
        public void setBinding(Products products){
            if(itemProductsBinding.getViewHolder() == null){
                itemProductsBinding.setViewHolder(this);
            }
            id.set(String.valueOf(products.getId()));
            name.set(products.getName());
            min_price.set(String.valueOf(products.getMin_price()));
            original_price.set(String.valueOf(products.getOriginal_price()));
            value.set(products.getValue());
            new LoadImage(products.getImgLink(), image).execute();
//            tv.setPaintFlags(tv.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
//            tv2.setPaintFlags(tv2.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
    }

}
