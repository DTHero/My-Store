package com.example.productsapp;

import android.databinding.DataBindingUtil;
import android.databinding.ObservableField;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.example.productsapp.databinding.ItemProductsBinding;

import java.util.List;

/**
 * Created by intern.ntthien on 6/27/2017.
 */

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ViewHolder>{
    private List<Products> products;
    public ProductsAdapter(List<Products> products){
        this.products=products;
    }
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        ItemProductsBinding itemProductsBinding= DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),R.layout.item_products, parent, false);
        return new ViewHolder(itemProductsBinding);
    }
    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        holder.setBinding(products.get(position),position);
    }
    @Override
    public int getItemCount(){
        return products.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        public ObservableField<String> stt = new ObservableField<>();
        public ObservableField<String> firstName = new ObservableField<>();
        public ObservableField<String> lastName = new ObservableField<>();
        private ItemProductsBinding itemProductsBinding;

        public ViewHolder(ItemProductsBinding itemViews){
            super(itemViews.getRoot());
            this.itemProductsBinding=itemViews;
        }
        public void setBinding(Products products, int position){
            if(ItemProductsBinding.getViewHolder() == null){
                ItemProductsBinding.setViewHolder(this);
            }
            stt.set(String.valueOf(position));
//            firstName.set(products.getfirstName());
//            lastName.set(products.getlastName());;
        }
    }

}
