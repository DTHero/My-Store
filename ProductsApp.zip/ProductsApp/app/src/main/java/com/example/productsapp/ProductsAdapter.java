package com.example.productsapp;

import android.databinding.DataBindingUtil;
import android.databinding.ObservableField;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.example.productsapp.databinding.ItemProductsBinding;

import java.util.List;

/**
 * Created by intern.ntthien on 6/27/2017.
 */

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ViewHolder>{

    private List<Products> products;

    public ProductsAdapter(List<Products> products){
        this.products=products;
    }

    public ProductsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        ItemProductsBinding itemProductsBinding= DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),R.layout.item_products, parent, false);
        return new ViewHolder(itemProductsBinding);
    }   //Create new ViewHolder.

    @Override
    public void onBindViewHolder(ProductsAdapter.ViewHolder holder, int position){
        holder.setBinding(products.get(position),position);
    }   //Binding data and view

    @Override
    public int getItemCount(){
        return products.size();
    } //Return the numbers of items

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ObservableField<String> id = new ObservableField<>();
        public ObservableField<String> name = new ObservableField<>();
        public ObservableField<String> min_price = new ObservableField<>();
        public ObservableField<String> original_price = new ObservableField<>();
        public ObservableField<String> value = new ObservableField<>();
        private ItemProductsBinding itemProductsBinding;

        public ViewHolder(ItemProductsBinding itemView){
            super(itemView.getRoot());
            this.itemProductsBinding=itemView;
        }
        public void setBinding(Products products, int position){
            if(itemProductsBinding.getViewHolder() == null){
                itemProductsBinding.setViewHolder(this);
            }
            id.set(products.getId());
            name.set(products.getName());
            min_price.set(products.getMin_price());
            original_price.set(products.getOriginal_price());
            value.set(products.getValue());
        }
    }

}
